
# Binobot Project
Este projeto é um **bot automatizado** que pode ser controlado via interface de linha de comando ou dashboard web.

## Como rodar o projeto

1. Clone o repositório:
   ```bash
   git clone https://github.com/mzueirobot/binobot_auto.git
   ```

2. Abra o projeto no Visual Studio ou outra IDE C#.

3. Execute o projeto.

## Funcionalidades
- Iniciar o bot
- Controle do bot via interface de linha de comando ou painel web.
